import express from "express";
import cors from "cors";
import rateLimit from "express-rate-limit";

const app = express();
const port = Number(process.env.PORT || 3000);

app.disable("x-powered-by");
app.use(express.json({ limit: "80kb" }));
app.use(cors({
  origin: process.env.ALLOWED_ORIGIN
    ? process.env.ALLOWED_ORIGIN.split(",").map(x => x.trim()).filter(Boolean)
    : true
}));
app.use("/api/", rateLimit({
  windowMs: 60 * 1000,
  limit: Number(process.env.RATE_LIMIT_PER_MINUTE || 15),
  standardHeaders: "draft-7",
  legacyHeaders: false
}));

app.get("/", (_req, res) => {
  res.type("text/plain").send("Ariamehr API is running. See /health.");
});
app.get("/health", (_req, res) => {
  res.json({ ok: true, service: "Ariamehr API", chatConfigured: Boolean(process.env.AI_API_KEY && process.env.AI_API_URL && process.env.AI_MODEL) });
});

// Compatible with Ariamehr v29 HTML:
// POST /api/chat { message, history:[{who,text}], userName }
// response: { reply }
app.post("/api/chat", async (req, res) => {
  const { AI_API_KEY: apiKey, AI_API_URL: apiUrl, AI_MODEL: model } = process.env;
  if (!apiKey || !apiUrl || !model) {
    return res.status(503).json({ error: "اتصال هوش مصنوعی هنوز در تنظیمات سرور کامل نشده است." });
  }

  const message = typeof req.body?.message === "string" ? req.body.message.trim() : "";
  if (!message) return res.status(400).json({ error: "پیام خالی است." });
  if (message.length > 4000) return res.status(413).json({ error: "پیام بیش از حد طولانی است." });

  const userName = typeof req.body?.userName === "string" ? req.body.userName.slice(0, 80) : "";
  const history = Array.isArray(req.body?.history) ? req.body.history.slice(-20) : [];
  // The HTML records the newest user message before sending the request; avoid duplicating it.
  if (history.length && history[history.length - 1]?.who === "user" && history[history.length - 1]?.text?.trim() === message) history.pop();
  const messages = [{
    role: "system",
    content: `تو آریامهر هستی؛ دستیار هوشمند فارسی‌زبان، دوستانه و روشن. طبیعی و روان به فارسی پاسخ بده. اگر نام کاربر در دسترس بود، فقط در صورت مناسب بودن از آن استفاده کن. اگر پاسخ را نمی‌دانی، صادقانه بگو. نام کاربر: ${userName || "ثبت نشده"}.`
  }];

  for (const item of history) {
    if (!item || typeof item.text !== "string") continue;
    const role = item.who === "user" ? "user" : item.who === "bot" ? "assistant" : null;
    if (!role) continue;
    const content = item.text.trim().slice(0, 3000);
    if (content) messages.push({ role, content });
  }
  // The newest user message is sent explicitly by the current app.
  messages.push({ role: "user", content: message });

  try {
    const upstream = await fetch(apiUrl, {
      method: "POST",
      headers: {
        "Authorization": `Bearer ${apiKey}`,
        "Content-Type": "application/json"
      },
      body: JSON.stringify({ model, messages, temperature: 0.7 }),
      signal: AbortSignal.timeout(45000)
    });
    const raw = await upstream.text();
    let data = {};
    try { data = JSON.parse(raw); } catch {}
    if (!upstream.ok) {
      console.error("AI provider status:", upstream.status);
      return res.status(502).json({ error: "سرویس هوش مصنوعی خطا برگرداند." });
    }
    const reply = data?.choices?.[0]?.message?.content;
    if (typeof reply !== "string" || !reply.trim()) {
      return res.status(502).json({ error: "قالب پاسخ هوش مصنوعی قابل شناسایی نیست." });
    }
    return res.json({ reply: reply.trim() });
  } catch (err) {
    console.error("AI request failed:", err?.name || "Error");
    return res.status(502).json({ error: "اتصال به سرویس هوش مصنوعی برقرار نشد." });
  }
});

// Payment intentionally stays disabled until a real gateway is configured and
// a server-side callback/verification flow is implemented. Never fake success.
app.post("/api/create-checkout", (_req, res) => {
  return res.status(503).json({
    error: "درگاه پرداخت واقعی هنوز تنظیم و تأیید نشده است؛ هیچ پرداختی انجام نشد."
  });
});

app.listen(port, "0.0.0.0", () => console.log(`Ariamehr API listening on ${port}`));

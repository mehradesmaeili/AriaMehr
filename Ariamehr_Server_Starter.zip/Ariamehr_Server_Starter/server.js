import express from "express";
import cors from "cors";
import rateLimit from "express-rate-limit";

const app = express();
const port = Number(process.env.PORT || 3000);
app.use(express.json({ limit: "100kb" }));
app.use(cors({ origin: process.env.ALLOWED_ORIGIN ? process.env.ALLOWED_ORIGIN.split(",") : true }));
app.use("/api/", rateLimit({ windowMs: 60 * 1000, limit: 20, standardHeaders: "draft-7", legacyHeaders: false }));

app.get("/health", (_req, res) => res.json({ ok: true, service: "Ariamehr API" }));

app.post("/api/chat", async (req, res) => {
  const { AI_API_KEY: apiKey, AI_API_URL: apiUrl, AI_MODEL: model } = process.env;
  if (!apiKey || !apiUrl || !model) return res.status(503).json({ error: "Server is not configured." });
  const messages = req.body?.messages;
  if (!Array.isArray(messages) || messages.length === 0 || messages.length > 30)
    return res.status(400).json({ error: "messages must be a non-empty array (max 30)." });
  const cleanMessages = messages.map(m => ({
    role: ["system", "user", "assistant"].includes(m?.role) ? m.role : "user",
    content: String(m?.content ?? "").slice(0, 8000)
  }));
  try {
    const upstream = await fetch(apiUrl, {
      method: "POST",
      headers: { "Authorization": `Bearer ${apiKey}`, "Content-Type": "application/json" },
      body: JSON.stringify({ model, messages: cleanMessages, temperature: 0.7 }),
      signal: AbortSignal.timeout(45000)
    });
    const raw = await upstream.text();
    let data;
    try { data = JSON.parse(raw); } catch { data = {}; }
    if (!upstream.ok) return res.status(502).json({ error: "AI provider returned an error.", providerStatus: upstream.status });
    const reply = data?.choices?.[0]?.message?.content;
    if (typeof reply !== "string" || !reply.trim()) return res.status(502).json({ error: "Unexpected AI provider response format." });
    return res.json({ reply });
  } catch {
    return res.status(502).json({ error: "Could not reach AI provider. Check server configuration." });
  }
});
app.listen(port, "0.0.0.0", () => console.log(`Ariamehr API listening on ${port}`));
